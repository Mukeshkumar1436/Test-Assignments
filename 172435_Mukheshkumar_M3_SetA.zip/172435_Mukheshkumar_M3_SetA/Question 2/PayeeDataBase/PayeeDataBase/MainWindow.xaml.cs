﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : 172435_mukhem
 * Desc                 : Program for Deleting a Payee Record by using DataBase First Approach
 * Version              : 1.0
 * Last Modified Date   : 25-Mar-2019
 * Change Description   : Description on Deleting a Record by DataBase First Approach
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PayeeDataBase
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static PayeeDetails_172435 payee = new PayeeDetails_172435();
        TrainingEntities context = new TrainingEntities();

        public MainWindow()
        {
            InitializeComponent();
        }

        public void ShowData()
        {
            try
            {
                context.SaveChanges();
                var data = from p in context.PayeeDetails_172435 select p;
                dgPayee.ItemsSource = data.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        // Funtion for a Button to Deleteing an Payee Record
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string MobileNumber = txtMobNum.Text;
                payee = (from p in context.PayeeDetails_172435
                         where p.Mobile_Number == MobileNumber
                         select p).FirstOrDefault();
                context.PayeeDetails_172435.Remove(payee);

                ShowData();
                Clear();

                Console.WriteLine("Payee Record Deleted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {
            txtMobNum.Text = null;
        }
    }
}
