﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDM_Entities
{
    public class Payee
    {
        //Get or set Payee Name
        public string PayeeName { get; set; }
        //Get or set MobileNumber
        public string MobileNumber { get; set; }
        //Get or set Account Holder Name 
        public string AccountHolderName { get; set; }
        //Get or Set Account Number 
        public int AccountNumber { get; set; }
        //Get or set Account Branch
        public string AccountBranch { get; set; }
        //Get or set Account Type
        public string AccountType { get; set; }
    }
}
