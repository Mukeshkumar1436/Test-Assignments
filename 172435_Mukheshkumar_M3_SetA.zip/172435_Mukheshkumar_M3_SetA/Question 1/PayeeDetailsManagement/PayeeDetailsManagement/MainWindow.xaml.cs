﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : 172435_mukhem
 * Desc                 : Program for Account Payee Details 
 * Version              : 1.0
 * Last Modified Date   : 25-Mar-2019
 * Change Description   : Description on layers using WPF Application
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PDM_BAL; //Reference for BAL Library
using PDM_Entities; //Reference for Entities Library
using PDM_Exceptions; //Reference for Exceptions Library
using System.Data.SqlClient;

namespace PayeeDetailsManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //public new void Show()
        //{
        //    try
        //    {
        //        List<Payee> payeeList = PayeeValidationBAL.RetrievePayee();

        //        if (payeeList == null || payeeList.Count <= 0)
        //            throw new PayeeException("Records not available");
        //        else
        //        {
        //            dgPayee.DataContext = payeeList;
        //        }
        //    }
        //    catch (PayeeException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    catch (SystemException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
        }

        //Funtion for Button to Inserting a Payee Details
        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Payee payee = new Payee();

                payee.PayeeName = txtPayeeName.Text;
                payee.MobileNumber =  txtMobNum.Text;
                payee.AccountHolderName = txtAccHdName.Text;
                payee.AccountNumber = Convert.ToInt32(txtAccNum.Text);
                payee.AccountBranch = txtBranchName.Text;
                payee.AccountType = txtAccountType.Text;


                int recordsAffected = PayeeValidationBAL.InsertPayee(payee);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Payee Details Added");

                    Show();
                    Clear();
                }
                else
                {
                    throw new PayeeException("Payee Details not inserted");
                }


                lbl.Visibility = (Visibility)1;
               
                lbl2.Visibility = (Visibility)1;
                txtPayeeName.Visibility = (Visibility)1;
                lbl3.Visibility = (Visibility)1;
                txtAccHdName.Visibility = (Visibility)1;
                lbl4.Visibility = (Visibility)1;
                txtAccNum.Visibility = (Visibility)1;
                lbl5.Visibility = (Visibility)1;
                txtBranchName.Visibility = (Visibility)1;
                lbl6.Visibility = (Visibility)1;
                txtAccountType.Visibility = (Visibility)1;
                btnInsert.Visibility = (Visibility)1;
            }
            catch (PayeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }


        // Function for Button to Getting a Payee Details
        private void BtnGetDetails_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                  string MobileNumber  = txtMobNum.Text;

                Payee payee = PayeeValidationBAL.SearchPayee(MobileNumber);

                if (payee != null)
                {
                    
                    txtPayeeName.Text = payee.PayeeName;
                    txtAccHdName.Text = payee.AccountHolderName;
                    txtAccNum.Text = payee.AccountNumber.ToString();
                    txtBranchName.Text = payee.AccountBranch;
                    txtAccountType.Text = payee.AccountType;

                    lbl.Visibility = 0;
                    
                    lbl2.Visibility = 0;
                    txtPayeeName.Visibility=0;
                    lbl3.Visibility = 0;
                    txtAccHdName.Visibility = 0;
                    lbl4.Visibility = 0;
                    txtAccNum.Visibility = 0;
                    lbl5.Visibility = 0;
                    txtBranchName.Visibility = 0;
                    lbl6.Visibility = 0;
                    txtAccountType.Visibility = 0;
                    btnInsert.Visibility = 0;

                }
                else
                    throw new PayeeException("No Account linked with this Mobile Number");
            }
            catch (PayeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {
            txtPayeeName.Text = "";
            txtBranchName.Text = "";
            txtAccHdName.Text = "";
            txtAccNum.Text = "";
            txtAccountType.Text = "";
            txtMobNum.Text = "";

        }

    }
}
