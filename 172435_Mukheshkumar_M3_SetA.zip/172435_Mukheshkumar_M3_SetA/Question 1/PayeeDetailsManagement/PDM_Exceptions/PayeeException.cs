﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDM_Exceptions
{
    public class PayeeException : ApplicationException
    {
        //Default constructor
        public PayeeException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public PayeeException(string message)
            : base(message)
        { }

    }
}
