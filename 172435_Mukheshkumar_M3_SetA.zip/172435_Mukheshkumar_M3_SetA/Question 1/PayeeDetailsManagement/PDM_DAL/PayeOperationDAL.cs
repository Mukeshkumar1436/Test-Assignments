﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDM_Entities;
using PDM_Exceptions;
using System.Data.SqlClient;

namespace PDM_DAL
{
    public class PayeOperationDAL
    {
        //Funtion to Insert a Payee Details
        public static int InsertPayee(Payee payee)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertPayeeDetails4_172435";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Payee_Name", payee.PayeeName);
                cmd.Parameters.AddWithValue("@Mobile_Number", payee.MobileNumber);
                


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
                
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        //Function to Get Account Details based on Mobile Number
        public static Payee SearchPayee(string MobileNumber)
        {
            Payee payee = null;

            try
            {
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();

                cmd.CommandText = "usp_DisplayAccountDetails_172435";
                cmd.Parameters.AddWithValue("@Mobile_Number", MobileNumber);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    payee = new Payee();
                    dr.Read();
                   
                    payee.MobileNumber = dr["Mobile_Number"].ToString();
                    payee.AccountHolderName = dr["Account_Holder_Name"].ToString();
                    payee.AccountNumber = Convert.ToInt32(dr["Account_Number"]);
                    payee.AccountBranch = dr["Account_Branch"].ToString();
                    payee.AccountType = dr["Account_Type"].ToString();
                    

                }
                else
                {
                    throw new PayeeException("No Account linked with this Mobile Number");
                }
                cmd.Connection.Close();
            }
            catch (PayeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return payee;
        }


        //Function to retrieve all Payee record
        public static List<Payee> RetrievePayee()
        {
            List<Payee> payeeList = null;

            try
            {
                SqlCommand cmd = DataConnectionDAL.GenerateCommand();
                cmd.CommandText = "usp_DisplayPayeeDetails_172435";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    payeeList = new List<Payee>();
                    while (dr.Read())
                    {
                        Payee payee = new Payee();

                        payee.PayeeName = dr["Payee_Name"].ToString();
                        payee.MobileNumber = dr["Mobile_Number"].ToString();
                        payee.AccountHolderName =(dr["Account_Holder_Name"]).ToString();
                        payee.AccountNumber = (int)dr["Account_Number"];
                        payee.AccountBranch = dr["Account_Branch"].ToString();
                        payee.AccountType = dr["Account_Type"].ToString();


                        payeeList.Add(payee);
                    }
                }
                else
                    throw new PayeeException("Record not available");
                cmd.Connection.Close();
            }
            catch (PayeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return payeeList;
        }
    }
}
