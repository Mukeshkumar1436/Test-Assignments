﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDM_DAL;
using PDM_Entities;
using PDM_Exceptions;
using System.Text.RegularExpressions;


namespace PDM_BAL
{
    public class PayeeValidationBAL
    {
        //Validations
        public static bool ValildatePayee(Payee payee)
        {
            bool payeeValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Validation for Employee Name
                if (payee.PayeeName == String.Empty)
                {
                    payeeValidated = false;
                    message.Append("Payee Name should not be Blank\n");
                }

                else if (!Regex.IsMatch(payee.PayeeName, "[A-Z][a-z]+"))
                {
                    payeeValidated = false;
                    message.Append("Payee Name should have alphabets only\n");
                }

                //Validation for Mobile Number
                if (payee.MobileNumber == String.Empty)
                {
                    payeeValidated = false;
                    message.Append("Mobile Number should not be Blank\n");
                }
                else if (!Regex.IsMatch(payee.MobileNumber, "[6789][0-9]{9}"))
                {
                    payeeValidated = false;
                    message.Append("mobile number should be 10 digits and it should start with 6/7/8/9\n");
                }
                

            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            
            return payeeValidated;
        }

        //Funtion to Insert Payee Details 
        public static int InsertPayee(Payee payee)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildatePayee(payee))
                {
                    recordsAffected = PayeOperationDAL.InsertPayee(payee);
                }
                else
                    throw new PayeeException("Please provide valid Payee Information");
            }
            catch (PayeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to Getting Account Details using Mobile Number
        public static Payee SearchPayee(string MobileNumber)
        {
            Payee payee = null;

            try
            {
                payee = PayeOperationDAL.SearchPayee(MobileNumber);
            }
            catch (PayeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return payee;
        }


        //Retrieving the data
        public static List<Payee> RetrievePayee()
        {
            List<Payee> payeeList = null;

            try
            {
                payeeList = PayeOperationDAL.RetrievePayee();
            }
            catch (PayeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return payeeList;
        }
    }
}
