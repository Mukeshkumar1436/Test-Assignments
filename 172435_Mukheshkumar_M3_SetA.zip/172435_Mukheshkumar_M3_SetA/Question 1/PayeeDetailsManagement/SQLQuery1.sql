use Training_23Jan19_Pune

--Creating a PayeeDetails table
create Table PayeeDetails_172435
(
	Payee_Name				varchar(50)  NOT NULL,	
	Mobile_Number			CHAR(10)	Primary key,
	Account_Holder_Name		varchar(50) NOT NULL,
	Account_Number			char(20) NOT NULL,
	Account_Branch			varchar(50),
	Account_Type			char(20)
)

select * from PayeeDetails_172435



--Store Procedure for Inserting an Payee Details Record--
CREATE PROC usp_InsertPayeeDetails_172435
(
	@Payee_Name					varchar(50),  	
	@Mobile_Number				CHAR(10),	
	@Account_Holder_Name		varchar(50),
	@Account_Number				char(20),
	@Account_Branch				varchar(50),
	@Account_Type				char(20)
)
AS
BEGIN
	INSERT INTO PayeeDetails_172435(Payee_Name, Mobile_Number, Account_Holder_Name, Account_Number, Account_Branch, Account_Type)
	VALUES(@Payee_Name, @Mobile_Number, @Account_Holder_Name, @Account_Number, @Account_Branch, @Account_Type)
END

GO


--Stored Procedure for Displaying an Payee Details Record--
CREATE PROC usp_DisplayPayeeDetails_172435
AS
BEGIN
	SELECT * FROM PayeeDetails_172435
END


