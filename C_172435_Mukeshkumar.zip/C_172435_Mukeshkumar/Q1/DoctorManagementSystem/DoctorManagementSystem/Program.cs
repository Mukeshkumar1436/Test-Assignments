﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Custom_Exceptions;
using Doctor_Entities;
using DMS_BAL;

namespace DoctorManagementSystem
{
    class DoctorPL
    {
        //displaying the Doctor details which are added
        public static void AddDoctor()
        {
            try
            {
                Doctors doctor = new Doctors();
                Console.WriteLine("Enter Registration NO :");
                doctor.registrationNO = Console.ReadLine();
                Console.WriteLine("Enter Doctor Name :");
                doctor.DoctorName = Console.ReadLine();
                Console.WriteLine("Enter City :");
                doctor.City = Console.ReadLine();
                Console.WriteLine("Enter Area of Specialization :");
                doctor.AreaofSpecialization = Console.ReadLine();
                Console.WriteLine("Enter Clinic Address :");
                doctor.ClinicAddress = Console.ReadLine();
                Console.WriteLine("Enter Clinic Timings:");
                doctor.ClinicTimings = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Contact NO :");
                doctor.ContactNO = Console.ReadLine();
                doctorBAL.Add(doctor);
                Console.WriteLine("Inserted");

                List<Doctor> employees = DoctorBAL.GetAll();
                foreach (var item in employees)
                {
                    Console.WriteLine(item); //DMS_Entities.Doctors
                }

            }

            catch (DoctorValidationException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (DoctorNotFoundException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (ex1)
            {
                Console.WriteLine(ex1.Message);
            }



        }
    }
}