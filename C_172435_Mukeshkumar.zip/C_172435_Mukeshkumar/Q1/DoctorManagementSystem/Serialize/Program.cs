﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Doctor_Entities;

namespace IOSerialize
{ 
/*
 * Program demonstrating retriving Doctor Information
 */
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DoctorInfo doctorObj = new DoctorInfo(@"d:\DoctorInfo.txt");
                if (doctorObj.Exists)
                {
                    Console.WriteLine("Doctor Name = {0}", doctorObj.Name);
                    Console.WriteLine("Doctor length in Bytes = {0}", doctorObj.Length);
                    Console.WriteLine("Doctor Extension = {0}", doctorObj.Extension);
                    Console.WriteLine("Doctor Full path = {0}", doctorObj.FullName);
                    Console.WriteLine("Doctor Directory = {0}", doctorObj.DirectoryName);
                    Console.WriteLine("Doctor Parent Directory = {0}", doctorObj.Directory);
                    Console.WriteLine("Doctor Creation Date and Time = {0}", doctorObj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("Doctor Modified Date and Time = {0}", doctorObj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("Doctor Last Access Date and Time = {0}", doctorObj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("Doctor Attributes = {0}", doctorObj.Attributes.ToString());
                }
                else
                {
                    Console.WriteLine("Doctor does not Exists");
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}