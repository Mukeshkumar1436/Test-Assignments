﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Doctor_Entities;
using DoctorDAL;
using Custom_Exceptions;


namespace DMS_BAL
{
    public class DoctorBAL
    {
        public static List<Doctors> docs = new List<Doctors>();
        public static object docs;
        private static bool ValidateDoctors(Doctors doctors)
        {
            StringBuilder sb = new StringBuilder();
            bool validDoctor = true;

            // checking whether the entered Area of Specialization is Heart Specialist, Ophthamologist etc.,

            if ((doctor.AreaofSpecialization != "Heart Specialist") && (doctor.AreaofSpecialization != "Opthalmologist"))
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "Area of specialization should be Heart specialist or Ophthalmologist ");
            }

            // Checking whether the entered Registration number is 7 digits or not

            if (doctor.RegistrationNO.Length != 7)
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "Required 7 digits only");
            }
            if (validDoctor == false)
                throw new DoctorNotFoundException(sb.ToString());
            return validDoctor;

            // Checking whether the entered Name is
            if (doctor.DoctorName == string.Empty)
            {
                validDoctor = false;
                sb.Append(Environment.NewLine + "Doctor Name Required");

            }
        }
    }
}
