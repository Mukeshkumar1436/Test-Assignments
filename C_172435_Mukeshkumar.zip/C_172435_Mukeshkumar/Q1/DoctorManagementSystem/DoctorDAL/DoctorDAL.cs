﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Doctor_Entities;
using Custom_Exceptions;

namespace DoctorDAL
{
    //DAL for CRUD operations
    public class DoctorDAL
    {
        List<Doctor> doctors = new List<Doctor>();

        //Inserting Doctor into collection
        public void Insert(Doctor doctor)
        {
            try
            {
                doctors.Add(Doctor);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Update(Doctor doctor)
        {
            doctors.Add(doctor);
        }

        public void Delete(Doctor doctor)
        {
            try
            {
                for (int i = 0; i < doctors.Count; i++)
                {
                    if (doctor[i].EmpId = doctor.EmpId) ;
                    {
                        //doctor.remove(doctor[i]);
                        doctors.RemoveAt(i);
                        isDeleted = true;
                        break;

                    }
                }
                if (!isDeleted)
                {
                    throw new DoctorNotFoundException("Employee not found");
                }

            }
            catch
            {

            }
            doctors.Add(doctor);
        }

        public List<Doctor> SelectAll()
        {
            return doctors;
        }
    }
}