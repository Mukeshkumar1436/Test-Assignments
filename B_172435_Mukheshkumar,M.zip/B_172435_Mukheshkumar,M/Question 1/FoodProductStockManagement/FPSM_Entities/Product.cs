﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FPSM_Entities
{
    [Serializable]
    public class FoodProduct
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string ProductName { get; set; }
        public string AvailableStock  { get; set; }
        public string StocktobeDelivered { get; set; }
        public DateTime DateofDelivery { get; set; }
        public string Address { get; set; }


        public override string ToString()
        {
            return $"CategoryID: {CategoryID}{Environment.NewLine}CategoryName: {CategoryName}{Environment.NewLine}ProductName: {ProductName}{Environment.NewLine}" +
                $"AvailableStock: {AvailableStock}{Environment.NewLine}StocktobeDelivered : {StocktobeDelivered}{Environment.NewLine}DateofDelivery: {DateofDelivery}{Environment.NewLine}Address:{ Address } ";

        }
    }
}
