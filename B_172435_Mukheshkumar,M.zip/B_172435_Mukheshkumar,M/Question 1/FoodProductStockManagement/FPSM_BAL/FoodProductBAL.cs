﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FPSM_DAL; // Reference to DAL library
using FPSM_Entities; // Reference to Entities library
using FPSM_Exceptions; // Reference to Exceptions library
using System.Text.RegularExpressions;

namespace FPSM_BAL
{
    public class FoodProductBAL
    {
        FoodProductDAL foodProductDAL = new FoodProductDAL();

        //Validations 
        public bool IsValid(FoodProduct foodproduct)
        {
            bool valid = true;
            StringBuilder stringBuilder = new StringBuilder();

            //Validation for Product ID
            if ((foodproduct.CategoryID < 0) || (foodproduct.CategoryID > 99999))  // 101-99999
            {
                stringBuilder .Append("CategoryID should contain digits only!" + Environment.NewLine);
                valid = false;
            }
            //Validation for Category Name
            if (!Regex.IsMatch(foodproduct.CategoryName, @"^[\p{L} \.\-]+$"))
            {
                stringBuilder .Append("CategoryName should not be blank" + Environment.NewLine);
                valid = false;
            }
            //Validation for Category Name
            if (!Regex.IsMatch(foodproduct.CategoryName, @"^[\p{L} \.\-]+$"))
            {
                stringBuilder.Append("CategoryName should be Food or Grocery, " + Environment.NewLine);
                valid = false;
            }

            //Validation for Address
            if (foodproduct.Address != "Mumbai" && foodproduct.CategoryName != "Pune" && foodproduct.CategoryName != "Chennai" && foodproduct.CategoryName != "Bnagalore")
            {
                stringBuilder.Append("Address should be Mumbai or Pune or Chennai or Bangalore, " + Environment.NewLine);
                valid = false;
            }

            if (!valid)
            {
                throw new FoodProductValidationException(stringBuilder.ToString());
            }

            return valid;
        }

        //Display
        public static List<FoodProduct> GetAll()
        {
            return FoodProductDAL.SelectAll();
        }

        //Insert
        public void Add(FoodProduct foodproduct)
        {
            try
            {
                if (IsValid(foodproduct))
                {

                    foodProductDAL.Insert(foodproduct);
                }
            }
            catch (FoodProductValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
        }

        //Update
        public void Update(FoodProduct foodproduct)
        {
            try
            {
                if (IsValid(foodproduct) && Isexisted(foodproduct.CategoryID))
                {

                    foodProductDAL.Update(foodproduct);
                }
            }
            catch (FoodProductNotFoundException ex)
            {
                throw ex;
            }
            catch (FoodProductValidationException ex2)
            {
                throw ex2;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }

            bool Isexisted(int id)
            {
                try
                {
                    foreach (FoodProduct pro in FoodProductDAL.foodproducts)
                    {
                        if (id == pro.CategoryID)
                        {
                            return true;
                        }
                    }
                    throw new FoodProductNotFoundException("product is not existed");
                }
                catch (FoodProductNotFoundException ex)
                {
                    throw ex;
                }
            }

        }

        public static void Store(List<FoodProduct> prods)
        {
            FoodProductDAL.Store(prods);
        }

        //Serialize
        public static void SerializeData()
            {
                FoodProductDAL.SerializeData();
            }

            //Deserialize
            public static List<FoodProduct> DeSerializeData()
            {
                return FoodProductDAL.DeSerializeData();
            }
    }
 }


