﻿/*********************************************************************
 * File                 : Question 1
 * Author Name          : 172435_mukhem
 * Desc                 : Program for Food Product Stock management Details 
 * Version              : 1.0
 * Last Modified Date   : 18-Mar-2019
 * Change Description   : Description on layers
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FPSM_BAL; // Reference to BAL library
using FPSM_Entities; // Reference to Entities library
using FPSM_Exceptions; // Reference to Exceptions library
using System.IO;

namespace FoodProductStockManagement
{
    class Program
    {
        static List<FoodProduct> prods;
        //Function to print Menu
        static int PrintMenu()
        {
            Console.WriteLine("=========Menu========\n1.Add Food Product\n2.Update Product\n3.DisplayProduct");
            Console.WriteLine("\nSelect your choice: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        //Creating a product
        static FoodProduct CreatefoodProduct(int id)
        {
            FoodProduct foodproduct = new FoodProduct();
            foodproduct.CategoryID = id;
            Console.WriteLine("enter product details");
            Console.Write("Category ID: ");
            foodproduct.CategoryID = int.Parse(Console.ReadLine());
            Console.Write("Category Name: ");
            foodproduct.CategoryName = Console.ReadLine();
            Console.Write("Product Name: ");
            foodproduct.ProductName = Console.ReadLine();
            Console.Write("Available Stock: ");
            foodproduct.AvailableStock = Console.ReadLine();
            Console.Write("Stock to be Delivered: ");
            foodproduct.StocktobeDelivered = Console.ReadLine();
            Console.Write("Date of Delivery: ");
            foodproduct.DateofDelivery = DateTime.Parse(Console.ReadLine());
            Console.Write("Address: ");
            foodproduct.Address = Console.ReadLine();

            return foodproduct;
        }

        //Function to Diplay products using collection
        static void DisplayProducts(List<FoodProduct> prods)
        {
            foreach (var prd in prods)
            {
                Console.WriteLine(prd);
            }
        }

        static void Main(string[] args)
        {
            int count; FoodProductBAL productBAL = new FoodProductBAL();
            if (File.Exists(@"C:\Users\mukhem\Desktop\172435 M2\Question 1\FoodProductStockManagement\FoodProduct.txt"))
            {
                prods = FoodProductBAL.DeSerializeData();
                FoodProductBAL.Store(prods);

                if (prods.Count != 0)
                {
                    count = prods[prods.Count - 1].CategoryID;
                }
                else { count = 100; }
            }
            else { count = 100; }
            try
            {
                string choice2;

                do
                {
                    int choice = PrintMenu();
                    FoodProduct foodproduct = null;

                    int Id;
                    switch (choice)
                    {
                        case 1:
                            Id = ++count;
                            foodproduct = CreatefoodProduct(Id);
                            productBAL.Add(foodproduct);
                            Console.WriteLine("Food Product Inserted..");
                            break;
                        case 2:
                            Console.WriteLine("Enter Product Id");
                            Id = int.Parse(Console.ReadLine());
                            foodproduct = CreatefoodProduct(Id);
                            productBAL.Update(foodproduct);
                            break;
                        case 3:
                            prods = FoodProductBAL.GetAll();
                            foreach (var prd in prods)
                            {
                                Console.WriteLine(prd);
                            }
                            break;
                    }
                    FoodProductBAL.SerializeData();

                    Console.WriteLine("Enter 'y' for continue; Any letter for exit");
                    choice2 = Console.ReadLine();
                }

                while (choice2 == "y");
                Console.WriteLine("Thank you");
            }
            catch (FoodProductNotFoundException ex3)
            {
                Console.WriteLine(ex3.Message);

            }
            catch (FoodProductValidationException ex4)
            {
                Console.WriteLine(ex4.Message);
            }
            catch (Exception ex5)
            {
                Console.WriteLine(ex5.Message);
            }
            Console.ReadKey();
        }
    }
}
