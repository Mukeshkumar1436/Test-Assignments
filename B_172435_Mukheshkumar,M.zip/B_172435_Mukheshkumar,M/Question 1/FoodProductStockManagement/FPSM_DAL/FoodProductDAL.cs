﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FPSM_Entities; // Reference to Entities library
using FPSM_Exceptions; // Reference to Exceptions library
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace FPSM_DAL
{
    public class FoodProductDAL
    {
        //Creating a collection
        public static List<FoodProduct> foodproducts = new List<FoodProduct>();


        public static List<FoodProduct> SelectAll()
        {
            return foodproducts;
        }


        //Function to Insert the Food Product record
        public void Insert(FoodProduct foodproduct)
        {

            try
            {
                foodproducts.Add(foodproduct);
                Console.WriteLine("Added");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Function to Update the Food Product details
        public void Update(FoodProduct foodproduct)
        {
            try
            {

                if (foodproduct != null)
                {
                    var prd = foodproducts.SingleOrDefault(p => p.CategoryID == foodproduct.CategoryID);
                    prd.CategoryName = foodproduct.CategoryName;
                    prd.ProductName = foodproduct.ProductName;
                    prd.AvailableStock = foodproduct.AvailableStock;
                    prd.StocktobeDelivered = foodproduct.StocktobeDelivered;
                    prd.DateofDelivery = foodproduct.DateofDelivery;
                    prd.Address = foodproduct.Address;
                    Console.WriteLine("Updated");
                }
                else
                {
                    throw new FoodProductNotFoundException("product with Id: " + foodproduct.CategoryID + "Not Found");
                }
            }
            catch (FoodProductNotFoundException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }


        //Function to Serialize the Data
        public static void SerializeData()
        {

            FileStream stream;
            try
            {
                stream = new FileStream(@"C:\Users\mukhem\Desktop\172435 M2\Question 1\FoodProductStockManagement\FoodProduct.txt", FileMode.OpenOrCreate, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, foodproducts);
                stream.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public static void Store(List<FoodProduct> prods)
        {
            foodproducts = prods;

        }


        //Function to Deserialize the data
        public static List<FoodProduct> DeSerializeData()
        {
            FileStream stream;
            try
            {

                stream = new FileStream(@"C:\Users\mukhem\Desktop\172435 M2\Question 1\FoodProductStockManagement\FoodProduct.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                BinaryFormatter formatter = new BinaryFormatter();
                foodproducts = formatter.Deserialize(stream) as List<FoodProduct>;
                stream.Close();
                return foodproducts;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
