﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FPSM_Exceptions
{
    [Serializable]
    public class FoodProductNotFoundException : Exception
    {
        //Parameterized constructor with message parameter
        public FoodProductNotFoundException(string message) : base(message)
        {

        }
    }
}
