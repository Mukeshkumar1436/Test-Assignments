﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Directories_Retrieving
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.LoadFile(@"C:\Users\mukhem\Desktop\172435 M2\Question 1\FoodProductStockManagement\FPSM_BAL\bin\Debug\FPSM_BAL.dll");
            foreach (Type t in assembly.GetTypes())
            {
                Console.WriteLine(t.Name);
                if (t.Name == "FoodProductBAL")
                {
                    object obj = assembly.CreateInstance("Reflection02.FoodProductBAL");
                    PropertyInfo[] property = t.GetProperties();
                 
                    Console.WriteLine();

                }
            }

            Console.ReadKey();
        }
    }
}
