﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiplicationTable
{
    class Table
    {
        //Creating the Task
        public void table(int i)
        {
           
            Console.WriteLine("2*" + i + "=" + (2 * i) + "\n"); 
        }
    }
    class Program
    { 

        static void Main(string[] args)
        {
            //Starting the Task
            Table t = new Table();

            for (int i = 1; i<=10; i++)
            {
                t.table(i);

            }

            Console.WriteLine("Main method Completed.Press any key to Finish");
            Console.ReadKey();
        }

    }
    
}
