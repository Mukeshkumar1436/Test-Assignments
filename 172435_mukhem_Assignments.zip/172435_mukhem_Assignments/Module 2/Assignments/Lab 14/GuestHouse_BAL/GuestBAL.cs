﻿using Guest_Entities;
using Guest_Exception;
using GuestHouse_DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestHouse_BAL
{
    public class GuestBAL
    {
        private static bool ValidateGuest(Guest guest)
        {
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            if (guest.GuestID <= 0)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Invalid GuestId");
            }
            if (guest.GuestName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Name is Required");
            }
            if (guest.ContactNo.Length < 10)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Required 10 digit Contact Number");
            }
            if (validGuest == false)
            {
                throw new GuestHouseException(sb.ToString());
            }
            return validGuest;
        }

        public static bool AddGuestBL(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(newGuest))
                {
                    Guest_DAL guestDAL = new Guest_DAL();
                    guestAdded = guestDAL.AddGuestDAL(newGuest);
                }
            }
            catch (GuestHouseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestAdded;
        }

        public static List<Guest> GetAllGuestBL()
        {
            List<Guest> guestList = null;
            try
            {
                Guest_DAL guestDAL = new Guest_DAL();
                guestList = guestDAL.GetAllGuestDAL();
            }
            catch (GuestHouseException ex)
            {
                throw ex;
            }
            return guestList;
        }

        public static Guest SearchGuestBL(int searchGuestId)
        {
            Guest searchGuest = null;
            try
            {
                Guest_DAL guestDAL = new Guest_DAL();
                searchGuest = guestDAL.SearchGuestDAL(searchGuestId);
            }
            catch (GuestHouseException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;
        }
        public static Guest SearchGuestByRelationBL(Relation rel)
        {
            Guest searchGuest = null;
            try
            {
                Guest_DAL guestDAL = new Guest_DAL();
                searchGuest = guestDAL.SearchGuestByRelationDAL(rel);
            }
            catch (GuestHouseException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;
        }

        public static bool UpdateGuestBL(Guest updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                if (ValidateGuest(updateGuest))
                {
                    Guest_DAL guestDAL = new Guest_DAL();
                    guestUpdated = guestDAL.UpdateGuestDAL(updateGuest);
                }
            }
            catch (GuestHouseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestUpdated;
        }

        public static bool DeleteGuestBL(int deleteGuestId)
        {
            bool guestDeleted = false;
            try
            {
                if (deleteGuestId > 0)
                {
                    Guest_DAL guestDAL = new Guest_DAL();
                    guestDeleted = guestDAL.DeleteGuestDAL(deleteGuestId);
                }
                else
                {
                    throw new GuestHouseException("Invalid GuestId");
                }
            }
            catch (GuestHouseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestDeleted;
        }


    }
}

