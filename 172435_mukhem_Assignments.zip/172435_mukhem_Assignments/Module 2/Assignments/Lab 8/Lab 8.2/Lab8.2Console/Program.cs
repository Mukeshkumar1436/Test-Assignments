﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8._2Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hashtable = GetHashtable();
            bool key = GetHashtable().ContainsKey("Perimeter");
            if (key)
            {
                Console.WriteLine("perimeter key is present");
            }
            else
            {
                Console.WriteLine("key not present");
            }
            Console.WriteLine("the value of Area key is:" + hashtable["Area"]);
            hashtable.Remove("Mortgage");
            Console.WriteLine("the value of mortgage:" + hashtable["Mortgage"]);
            Console.WriteLine("mortgage is removed");

            Console.ReadLine();

            Console.ReadKey();
        }


        static Hashtable GetHashtable()
        {
            
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;


        }
        
    }
}
