﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product
{
    class ProductDemo
    {


        static void Main(string[] args)
        {
                int productID;
                string productName;
                  double price;
                 int quantity;
            Console.Write("enter product ID:");
            productID = Convert.ToInt32(Console.ReadLine());
            Console.Write("enter product Name:");
            productName = Console.ReadLine();
            Console.Write("enter product Price:");
            price =Convert.ToDouble( Console.ReadLine());
            Console.Write("enter product Quality:");
            quantity =Convert.ToInt32( Console.ReadLine());
            object obj1 = productID;
            object obj2 = productName;
            object obj3 = price;
            object obj4 = quantity;

            int productID1 =(int) obj1;
            string productName1 = (string)obj2;
            double price1 = (double)obj3;
            int quantity1 = (int)obj4;
           
            Console.WriteLine("======================================================");

            Console.WriteLine("product details are :");
            Console.WriteLine($"Product ID is: {productID1}");
            Console.WriteLine($"Product Name is : { productName1}");
            Console.WriteLine($"product Price : {price1}");
            Console.WriteLine($"Product Quantity is :{ quantity1}");
            Console.WriteLine($"TOtal Amount is :{price1 * quantity1}");





        }

        


            
          



               





    }
}





