﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bird
{
    class Bird
    {
        static void Main(string[] args)
        {
            string a = "Eagle";
            Bird1 b = new Bird1( a,100);

            b.fly();
            b.fly(300);



        }



    }
}