﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Clc c = new Clc();
            int n1 = 4;
            int n2 = 5;
            
            int res = c.Add(n1, n2);
            Console.WriteLine(res);
            Console.ReadLine();






        }
    }
}
