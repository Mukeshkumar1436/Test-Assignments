﻿using System;
namespace Patient
{
    public class Patient
    {
        public int patientId { get; set; }
        public string patientName { get; set; }
        public PatientType patientCategory { get; set; }

        public Patient()
        {

        }
        public Patient(int pid, string pname, PatientType pcategory)
        {
            patientId = pid;
            patientName = pname;
            patientCategory = pcategory;
        }

    }
    public enum PatientType { IN = 1, OUT =0 }
}


