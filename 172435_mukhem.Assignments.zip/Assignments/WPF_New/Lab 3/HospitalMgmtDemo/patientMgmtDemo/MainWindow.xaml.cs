﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace patientMgmtDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddPatient_Click(object sender, RoutedEventArgs e)
        {
            Patient.Patient pt = new Patient.Patient();
            pt.patientName = txtPatientName.Text;
            pt.patientCategory = (Patient.PatientType)Convert.ToInt32(txtPatientCategory.Text);
            int i = PatientDbDAL.AddPatient(pt);

            if (i == 1)
            {
                MessageBox.Show("Records updated");
                GetPatients();
            }
            else
            {
                MessageBox.Show("Something went wrong");
            }

        }
        private void GetPatients()
        {
            List<Patient.Patient> Patients1 = new List<Patient.Patient>();
            List<Patient.Patient> lst = new List<Patient.Patient>();
            lst = PatientDAL.PatientDAL.PatientDal();

            Patients1.AddRange(lst);
            List<Patient.Patient> lstdb = new List<Patient.Patient>();
            lstdb = PatientDbDAL.GetAllData();
            Patients1.AddRange(lstdb);
            dgPatient.DataContext = Patients1;
        }

        private void btnGetPatients_Click(object sender, RoutedEventArgs e)
        {

            GetPatients();
        }

        //private void Window_Loaded(object sender, RoutedEventArgs e)
        //{
        //    GetPatients();
        //}
    }

}
