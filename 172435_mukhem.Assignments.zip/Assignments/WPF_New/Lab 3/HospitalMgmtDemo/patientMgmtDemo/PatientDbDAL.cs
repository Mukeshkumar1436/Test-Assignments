﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace patientMgmtDemo
{
    class PatientDbDAL
    {
        static string ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_14Nov18_Mumbai;User ID=sqluser;Password=sqluser";
        static SqlConnection Connection = new SqlConnection(ConnectionString);
        public static List<Patient.Patient> GetAllData()
        {
            List<Patient.Patient> lstpatient = new List<Patient.Patient>();
            string Query = "select * from PatientMaster_165994";
            SqlCommand command = new SqlCommand(Query, Connection);
            try
            {
                Connection.Open();
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable Table = new DataTable();
                da.Fill(Table);

                foreach (DataRow row in Table.Rows)
                {
                    Patient.Patient patient = new Patient.Patient();
                    patient.patientId = Convert.ToInt32(row["PatientId"]);
                    patient.patientName = row["PatientName"].ToString();
                    patient.patientCategory = (Patient.PatientType)Convert.ToInt32(row["PatientCategory"]);
                    lstpatient.Add(patient);
                }


            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured" + Exception.ToString());

            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured" + Exception.ToString());
            }
            finally
            {
                Connection.Close();
            }
            return lstpatient;
        }
        public static int AddPatient(Patient.Patient Pt)
        {
            int res = 0;
            String Query = "Insert into PatientMaster_165994(PatientName,PatientCategory) Values(@PatientName,@PatientCategory)";
            SqlCommand command = new SqlCommand(Query, Connection);
            try
            {
                Connection.Open();
                command.Parameters.AddWithValue("@PatientName", Pt.patientName);
                command.Parameters.AddWithValue("@PatientCategory", Pt.patientCategory);
                res = command.ExecuteNonQuery();
                Connection.Close();
            }

            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured" + Exception.ToString());

            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured" + Exception.ToString());
            }
            finally
            {
                Connection.Close();
            }
            return res;
        }
    }

}
