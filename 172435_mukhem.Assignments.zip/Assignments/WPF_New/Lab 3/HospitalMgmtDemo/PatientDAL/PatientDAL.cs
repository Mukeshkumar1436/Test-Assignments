﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDAL
{
    public class PatientDAL
    {


        public static List<Patient.Patient> PatientDal()
        {
            List<Patient.Patient> Patients = new List<Patient.Patient>
            {
                new Patient.Patient{patientId=201,patientName="Balayya",patientCategory=Patient.PatientType.IN},
                 new Patient.Patient{patientId=203,patientName="Chandra",patientCategory=Patient.PatientType.OUT},
                  new Patient.Patient{patientId=203,patientName="Lokesh",patientCategory=Patient.PatientType.IN}
            };
            return Patients;
        }
    }
}
