﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HospitalMgmtDemo
{
    
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int count = 1;
        public MainWindow()
        {
            InitializeComponent();
           
        }

        public int CountNum()
        {
           
            return count++;
        }
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtName.Text="";
            txtPass.Text ="";
        }

        private void txtName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            string uName = txtName.Text;
            bool flag = IsAlpha(uName);
            if (!flag)
            { 
                MessageBox.Show("Invalid Login.. username only contains characters");
            }

        }

        public bool IsAlpha(string input)
        {
            return Regex.IsMatch(input, "^[a-zA-Z]+$");
        }

        private  void btnLogin_Click(object sender, RoutedEventArgs e)
        {

            string uName = txtName.Text;
            string uPass = txtPass.Text;

           
            if (uName=="admin" && uPass=="admin")
            {
                MessageBox.Show("Login successful");
            }
            else
            {
                MessageBox.Show("Invalid Login.. username only contains characters");
                int c = CountNum();

                if (c > 3)
                {
                    Environment.Exit(0);
                }
            }
         

        }
    }
}
