﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LinqWPFdemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EmployeeContext empContext = new EmployeeContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // dgEmp.DataContext = empContext.emp.ToList();

            //dgEmp.DataContext = empContext.emp.ToList().Where(x=>x.City!="Mumbai");

            //dgEmp.DataContext = empContext.emp.ToList().Where(x => x.Title == "Manager");

            //dgEmp.DataContext = empContext.emp.ToList().Where(x=>x);

            //int EmployeeCount = empContext.emp.Count();
            //MessageBox.Show("No of rows : "+EmployeeCount.ToString());

            // dgEmp.DataContext = empContext.emp.ToList().OrderByDescending(i => i.EmployeeID).Take(1);

            var EmpCountCity = empContext.emp.GroupBy(i=>i.City).ToList();
            MessageBox.Show("No of rows : " + EmpCountCity.ToString());


            //dgData.DataContext = con.employess.ToList().Where(s => s.DOJ > DateTime.Parse( "2015-01-01"));
            // dgData.DataContext = con.employess.ToList().Where(s => s.DOJ < DateTime.Parse("2015-01-01"));

            // dgData.DataContext = con.employess.ToList().Where(s => s.DOB > DateTime.Parse("1990-01-01"));
            //  dgData.DataContext = con.employess.ToList().Where(s => s.Title== "Consultant " || s.Title=="Associate ");

            //MessageBox.Show(""+ con.employess.ToList().Count());
            //  MessageBox.Show("" + con.employess.ToList().Where(s => s.City == "Mumbai ").Count());
        }
    }
}
