﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emp1List = new List<Employee>();
            empList.ToList().ForEach(x => { Console.WriteLine(x.EmployeeID + "  " + x.FirstName + "  " + x.LastName + "  " + x.DOB + "  " + x.DOJ + "  " + x.Title + "  " + x.City + "\n"); });

            Console.WriteLine("*******************************************");
            emp1List.Add((Employee)empList.ToList().Where(x=>x.City!="Mumbai"));
            emp1List.ToList().ForEach(x => { Console.WriteLine(x.EmployeeID + "  " + x.FirstName + "  " + x.LastName + "  " + x.DOB + "  " + x.DOJ + "  " + x.Title + "  " + x.City + "\n"); });

            Console.ReadKey();
        }

        static List<Employee> empList = new List<Employee> {

            new Employee{EmployeeID = 1001,
            FirstName = "Malcolm",
            LastName = "Daruwalla",
            Title = "Manager",
            DOB = Convert.ToDateTime("16/11/1984"),
            DOJ = Convert.ToDateTime("8 /6/2011"),
            City = "Mumbai"},

             new Employee{EmployeeID = 1002,
            FirstName = "asdin",
            LastName = "Dhalla",
            Title = "AsstManager",
            DOB = Convert.ToDateTime("20/08/1984"),
            DOJ = Convert.ToDateTime("7/7/2012"),
            City = "Mumbai"} ,



        new Employee{EmployeeID = 1003,
            FirstName = "Madhavi ",
            LastName = "Oza ",
            Title = "Consultant ",
            DOB = Convert.ToDateTime("14/11/1987"),
            DOJ = Convert.ToDateTime("12/4/2015"),
            City = "Pune"},



        new Employee{EmployeeID = 1004,
            FirstName = "Saba",
        LastName = "Shaikh",
            Title = "SE",
            DOB = Convert.ToDateTime("3/6/1990"),
            DOJ = Convert.ToDateTime("2/2/2016"),
            City = "Pune"} };
            


           

}
}
