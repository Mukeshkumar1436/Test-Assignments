﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace LAB_3
{
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con = new SqlConnection(@"Data Source=IN-MUM-LNVM065\SQLEXPRESS;Initial Catalog=training;Integrated Security=True");

            con.Open(); ds = new DataSet();               //select - For Data Retrieval               
            da = new SqlDataAdapter("select * from applicationusers", con);

            //So that we should be able to save changes back to database....               
            SqlCommandBuilder bld = new SqlCommandBuilder(da);

            da.Fill(ds, "appusers");

            dgData.DataContext = ds.Tables["appusers"];
        }

        private void Save_Changes_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                //Save Changes to Database 
                da.Update(ds.Tables["appusers"]);
                MessageBox.Show("Changes Saved");
            }
            catch (SqlException sqlex) { MessageBox.Show(sqlex.Message); }
        }

        private void Cancel_Changes_Click(object sender, RoutedEventArgs e)
        {
            ds.Tables["appusers"].RejectChanges();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Iterate through Rows of DataTable and display RowStates ..... 

            foreach (DataRow drow in ds.Tables["appusers"].Rows)
            {
                if (drow.RowState == DataRowState.Deleted)
                {
                    MessageBox.Show(drow["username", DataRowVersion.Original].ToString() + " deleted ");
                }
                else MessageBox.Show(drow["username"].ToString() + "  " + drow.RowState.ToString());
            }
        }
    }
}
