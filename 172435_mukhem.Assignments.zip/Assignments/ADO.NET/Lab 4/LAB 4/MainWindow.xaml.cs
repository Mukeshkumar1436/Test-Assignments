﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

namespace LAB_4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con = new SqlConnection(@"Data Source=IN-MUM-LNVM065\SQLEXPRESS;Initial Catalog=training;Integrated Security=True");

            con.Open(); ds = new DataSet();               //select - For Data Retrieval               
            da = new SqlDataAdapter("select * from customer1", con);

            //So that we should be able to save changes back to database....               
            SqlCommandBuilder bld = new SqlCommandBuilder(da);

            da.Fill(ds, "cust");

            dgData.DataContext = ds.Tables["cust"];
        }
      

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           ds.Tables["cust"].DefaultView.Sort = cmbcolumnlist.Text;
           dgData.DataContext = ds.Tables["cust"];
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ds.Tables["cust"].DefaultView.RowFilter = "City like '" + txtcity.Text + "'";
            dgData.DataContext = ds.Tables["cust"];

        }
    }
}