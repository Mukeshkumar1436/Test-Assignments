﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EmployeeCodeFirst
{
    class EmployeeEntities
    {
        [Key]
        public int Emp_Code { get; set; }
        public string Emp_Name { get; set; }
        public double Emp_Salary { get; set; }
        public DateTime Emp_DOJ { get; set; }


    }
}
