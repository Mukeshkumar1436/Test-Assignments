﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeCodeFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static EmployeeEntities employee = new EmployeeEntities();
        dbEmployee context = new dbEmployee();
        public MainWindow()
        {
            InitializeComponent();
        }

        public void ShowData()
        {
            context.SaveChanges();
            var data = from p in context.dbset select p;
            dgEmployee.ItemsSource = data.ToList();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            //context.dbset.Add(new EmployeeEntities { Emp_Code = 101, Emp_Name = "Mukesh", Emp_Salary = 50000, Emp_DOJ = DateTime.Now });

            //context.SaveChanges();
            //dgEmployee.ItemsSource = context.dbset.ToList();

            //var data = from p in context.dbset select p;

            //dgEmployee.ItemsSource = data.ToList();

            ///* int Id = 172435; *///Convert.ToInt32(txtSalary.Text);
            //var employee = (from p in context.dbset
            //                where p.Emp_Code == 172434
            //                select p);

            //dgEmployee.ItemsSource = employee.ToList();


            //employee = (from p in context.dbset
            //            where p.Emp_Code == 172
            //            select p).FirstOrDefault();
            //employee.Emp_Salary = 135;

            //var x = (from p in context.dbset
            //         where p.Emp_Code == 172434
            //         select p);

            //dgEmployee.ItemsSource = x.ToList();



            ShowData();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                employee.Emp_Code = int.Parse(txtCode.Text);
                employee.Emp_Name = txtName.Text;
                employee.Emp_Salary = Convert.ToInt64(txtSalary.Text);
                employee.Emp_DOJ = Convert.ToDateTime(txtDOJ.Text);

                context.dbset.Add(employee);
                MessageBox.Show("added");
                ShowData();
                Clear();
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                int Id = Convert.ToInt32(txtSalary.Text);
                employee = (from p in context.dbset
                            where p.Emp_Code == Id
                            select p).FirstOrDefault();
                txtCode.Text = Convert.ToString(employee.Emp_Code);
                txtName.Text = employee.Emp_Name;
                txtSalary.Text = Convert.ToString(employee.Emp_Salary);
                txtDOJ.Text = Convert.ToString(employee.Emp_DOJ);

                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                int Id = Convert.ToInt32(txtCode.Text);
                employee = (from p in context.dbset
                            where p.Emp_Code == Id
                            select p).FirstOrDefault();
                employee.Emp_Code = int.Parse(txtCode.Text);
                employee.Emp_Name = txtName.Text;
                employee.Emp_Salary = Convert.ToInt64(txtSalary.Text);
                employee.Emp_DOJ = Convert.ToDateTime(txtDOJ.Text);

                ShowData();
                Clear();

            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                try
                {
                    int Id = Convert.ToInt32(txtCode.Text);
                    employee = (from p in context.dbset
                                where p.Emp_Code == Id
                                select p).FirstOrDefault();
                    context.dbset.Remove(employee);

                    ShowData();
                    Clear();
                    Console.WriteLine("Record Deleted");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            using (context)
            {
                try
                {
                    var count = (from j in context.dbset
                                 select j).Count();
                    MessageBox.Show("count is: " + count);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Button_Click_search_DeptCode(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtSalary.Text);
                var k = from j in context.dbset
                        where j.Emp_Salary == id
                        select j;
                dgEmployee.ItemsSource = k.ToList();

                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {
            txtCode.Text = null;
            txtName.Text = null;
            txtSalary.Text = null;
            txtDOJ.Text = null;

            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
