-- LAB 2
create table applicationusers(  userid varchar(10) primary key,  username varchar(30) not null,  
city varchar(30) not null,  password varchar(30) check(len(password) >5) ) 
 
 --LAB 4
 create table customer1( customerid int identity primary key,  customername varchar(50),  
 city varchar(30),  creditlimit numeric(10,2) ) 
 
 --LAB 5
 USE [Training_23Jan19_Pune]
GO

/****** Object:  Table [dbo].[Category]    Script Date: 25-03-2019 15:14:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Category](
	[CategoryId] [int] NOT NULL,
	[Cat_name] [varchar](50) NULL,
 CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


USE [training]
GO

/****** Object:  Table [dbo].[Products]    Script Date: 25-03-2019 15:14:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Products](
	[ProductId] [int] NOT NULL,
	[Prod_name] [varchar](50) NULL,
	[CategoryId] [int] NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


