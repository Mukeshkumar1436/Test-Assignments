USE [Training_23Jan19_Pune]
GO

/****** Object:  Table [dbo].[employee_172435]    Script Date: 25-03-2019 17:06:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[employee1_172435](
    [empno] [int] NOT NULL,
    [empname] [varchar](50) NOT NULL,
    [empsal] [numeric](10, 2) NULL,
    [emptype] [varchar](1) NULL,
PRIMARY KEY CLUSTERED 
(
    [empno] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[employee1_172435]  WITH CHECK ADD CHECK  (([empsal]>=(25000)))
GO

ALTER TABLE [dbo].[employee1_172435]  WITH CHECK ADD CHECK  (([emptype]='P' OR [emptype]='C'))
GO

/****** Object:  StoredProcedure [dbo].[GetEmployeeById_172435]    Script Date: 25-03-2019 17:03:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 CREATE proc [dbo].[AddEmployeeById_172435] 
 (  
 @empno int ,  
 @empname varchar(50) , 
 @empsal numeric(10,2) ,  
 @emptype varchar(1)
  )
 as 
 insert into employee1_172435(empno,empname,empsal,emptype)values
(@empno,@empname,@empsal,@emptype)

-----
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
 CREATE proc [dbo].[GetEmployee1ById_172435] (@empno int )
  as 
  select * from employee1_172435 where empno = @empno 
GO
/****** Object:  StoredProcedure [dbo].[AddEmployeeById_172435]    Script Date: 25-03-2019 17:04:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER proc [dbo].[AddEmployeeById_172435] 
 (  
 @empno int ,  
 @empname varchar(50) , 
 @empsal numeric(10,2) ,  
 @emptype varchar(1)
  )
 as 
 insert into employee1_172435(empno,empname,empsal,emptype)values
(@empno,@empname,@empsal,@emptype)



GO
/****** Object:  StoredProcedure [dbo].[DeleteEmployeeById_172435]    Script Date: 25-03-2019 17:05:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc [dbo].[DeleteEmployee1ById_172435] 
 (   @empno int )
  as 
 delete from employee1_172435 where empno = @empno 



GO



