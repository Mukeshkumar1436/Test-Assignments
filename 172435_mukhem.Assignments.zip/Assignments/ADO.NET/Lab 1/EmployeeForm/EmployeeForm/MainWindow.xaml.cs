﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace iGatepatni
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //SqlConnection con = new SqlConnection(@"server=atrgsql\sql2005;database=labdemos;” + “user id=sqluser;password=sqluser");
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_14Nov18_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            con.Open();
        }

        private void btnQuery_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployee1ById_165994", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //define procedure parameter 
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@empno";
                cmd.Parameters.Add(prm);

                //assign parameter value
                cmd.Parameters["@empno"].Value = int.Parse(txtempno.Text);

                //execute 
                dreader = cmd.ExecuteReader();

                //if employee record found 
                if (dreader.Read())
                {
                    txtempname.Text = dreader["empname"].ToString();
                    txtsalary.Text = dreader["empsal"].ToString();

                    if (dreader["emptype"].ToString() == "P")
                        rdpayroll.IsChecked = true;
                    else
                        rdconsultant.IsChecked = true;
                }
                else
                {
                    btnNew_Click(btnnew, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            txtempno.Text = "";
            txtempname.Text = "";
            txtsalary.Text = "";
            txtempno.Focus();
        }


        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {

                //The Insert DML to add employee record 
                SqlCommand cmd = new SqlCommand("insert into employee1_165994 values(@empno,@empname,@empsal,@emptype)", con);

                //The Parameters 
                cmd.Parameters.Add("@empno", SqlDbType.Int);
                cmd.Parameters.Add("@empname", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@empsal", SqlDbType.Decimal);
                cmd.Parameters.Add("@emptype", SqlDbType.VarChar, 1);

                //Assigning Values to parameters 
                cmd.Parameters["@empno"].Value = txtempno.Text;
                cmd.Parameters["@empname"].Value = txtempname.Text;
                cmd.Parameters["@empsal"].Value = txtsalary.Text;
                cmd.Parameters["@emptype"].Value = rdpayroll.IsChecked == true ? "P" : "C";

                //Execute Insert .... 
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("DeleteEmployee1ById_165994", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //define procedure parameter 
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@empno";
                cmd.Parameters.Add(prm);

                //assign parameter value
                cmd.Parameters["@empno"].Value = int.Parse(txtempno.Text);

                //execute 
                dreader = cmd.ExecuteReader();


                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Are you sure?", "Delete Confirmation", System.Windows.MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                    dreader.Close();


            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById_165994", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //The Insert DML to add employee record 
                //SqlCommand cmd = new SqlCommand("insert into employee_166067 values(@eno,@enm,@esal,@etyp)", con);

                //The Parameters 
                // cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@empname", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@empsal", SqlDbType.Decimal);
                cmd.Parameters.Add("@emptype", SqlDbType.VarChar, 1);

                //Assigning Values to parameters 
                //cmd.Parameters["@eno"].Value = txtempno.Text;
                cmd.Parameters["@empname"].Value = txtempname.Text;
                cmd.Parameters["@empsal"].Value = txtsalary.Text;
                cmd.Parameters["@emptype"].Value = rdpayroll.IsChecked == true ? "P" : "C";

                //Execute Insert .... 
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }
    }
}
