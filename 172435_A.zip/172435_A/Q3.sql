Use Training_23Jan19_Pune

CREATE TABLE Faculty_172435
(
	Faculty_ID		    INT				NOT NULL,
	Faculty_Name		VARCHAR(40)		NOT NULL,
	LoT      			VARCHAR(20)		NOT NULL,
	Manager_ID			INT				NOT NULL
)
INSERT INTO Faculty_172435(Faculty_ID,Faculty_Name,LoT,Manager_ID)
VALUES(110, 'Richard Jackson', '.Net', '101'),
	(120,'IvanaTeach','.Net',110)

INSERT INTO Faculty_172435(Faculty_ID,Faculty_Name,LoT,Manager_ID)
values(130,'Mukesh','.Net',115),
(140,'Manoj','.Net',125),
(150,'Sai','.Net',135)

select*from faculty_172435
EXEC sp_help Faculty_172435


CREATE TABLE Course_172435

(
	CourseID		INT			NOT NULL,
	CourseName		VARCHAR(40)		NOT NULL,
	Location      	VARCHAR(20)		NOT NULL,
	RoomNo			VARCHAR(20)		NOT NULL,
	FacultyID		INT				NOT NULL,
	StartDate		Date,
	Enddate			DATE
)

INSERT INTO Course_172435(CourseID,CourseName,Location,RoomNo,FacultyID,StartDate,Enddate)
VALUES(101,'C# 5.0','Banglore','Lab10',120,'12/Jan/2016','20/Jan/2016'),
	(105,'Windows Presentation Foundation','Mumbai','Lab 4',110,'02/Feb/2016','05/Feb/2016'),
	(115,'Windows Presentation Foundation','Hyderabad','Lab 6',130,'03/Mar/2016','07/Mar/2016'),
	(125,'SQL','Chennai','Lab 4',140,'04/Apr/2016','07/APR/2016'),
	(135,'Web Basics','Pune','Lab 4',150,'02/May/2016','08/May/2016')

select*from Course_172435
--1-DISPLAY Course Name,Room no and Location which are taugfht by Richard Jackson

SELECT CourseName,RoomNo,Location 
FROM Course_172435
WHERE FacultyID = 120

--2-DISPLAY CourseID and Course Name FOR THE Course whose name contains 'Windows' anywhere in course name

SELECT CourseID,CourseName
FROM Course_172435
WHERE CourseName = 'windows'

--5 Create a view Location_view to display course details based on location and hide the definition
CREATE VIEW Locationview_172435
WITH ENCRYPTION
AS
SELECT Location, count(CourseName) AS CourseName
FROM Course_172435
GROUP BY Location

SELECT * FROM Locationview_172435

--4 stored procedure
CREATE PROC usp_RetrieveCourseID_172435
(
    @CourseID       VARCHAR(30)
)
AS
BEGIN
    IF (@CourseID IS NULL OR @CourseID = '') 
    BEGIN
        PRINT 'CourseId should be provided'
    END
    ELSE
    BEGIN
        SELECT CourseID, CourseName, Location, RoomNo, Faculty_ID, Startdate, Enddate
        FROM Course_172435
        WHERE CourseID = @CourseID
    END
END


SELECT * FROM syscomments WHERE text LIKE '%172513%'

EXEC usp_RetrieveCourseID_172435 null

EXEC usp_RetrieveCourseID_172435 '.NET105'


--Executing the  stored procedure with result sets

EXEC usp_RetrieveCourseID_172435 '.NET105'
EXEC usp_RetrieveCourseID_172435 '.NET105' 
WITH RESULT SETS((CourseID VARCHAR(50), Course_Name VARCHAR(40), Location VARCHAR(40),Room_No VARCHAR(40),FacultyID INT,Startdate date,End_date date))


